import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

import java.io.Console;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;


public class Seleniumtraining {
    //private static WebDriver driver;

    //WebDriver driver= new ChromeDriver();

    public static void main (String[] args) throws InterruptedException {

        System.setProperty("webdriver.chrome.driver","D:\\web driver\\chromedriver.exe");
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("build", "your build name");
        capabilities.setCapability("name", "your test name");
        capabilities.setCapability("platformName", "Android");
        capabilities.setCapability("deviceName", "HTC 10");
        capabilities.setCapability("platformVersion","7");
        WebDriver driver= new ChromeDriver();
        driver.get("https://staging.upnest.com/re/loginuser?email=agentdemo6@gmail.com&passwd=lessthan6");
        //driver.manage().window().maximize();
        driver.findElement(By.className("agentDashboard-tab")).click();
        Thread.sleep(Long.parseLong("3000"));
        driver.findElement(By.cssSelector("body > div.modal-container > div > div > div > div > div.modal-footer.buttons > button.btn.btn-transparent")).click();
        Thread.sleep(Long.parseLong("3000"));
        driver.findElement(By.cssSelector("#imd-modal > div > div > div.modal-footer > button")).click();
      //  driver.findElement(By.name("search")).sendKeys("Cristiano Ronaldo");
      //  existsElement();

      //  driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);

      //  driver.get("https://www.youtube.com/");

      //  Thread.sleep(2000);

        //driver.findElement(By.linkText("Talk")).click();
//        //Thread.sleep(2000);
//        driver.navigate().to("https://www.fifa.com/");
//        Thread.sleep(2000);
//        driver.navigate().back();
//        Thread.sleep(3000);
//       // driver.close();


    }
//    public boolean start() {
//        try {
//            WebDriver driver= new ChromeDriver();
//            driver.findElement(By.cssSelector("#search-form > fieldset > button > i2")).click();
//        } catch (NoSuchElementException e) {
//            return false;
//        }
//        return true;
//    }

}
